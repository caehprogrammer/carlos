class MediaItem {
    var name: String
    init(name: String) {
        self.name = name
    }
}

class Movie: MediaItem {
    var director: String
    init(name: String, director: String) {
        self.director = director
        super.init(name: name)
    }
}

class Song: MediaItem {
    var artist: String
    init(name: String, artist: String) {
        self.artist = artist
        super.init(name: name)
    }
}


//: Optional Chaining

class Book {
    var author : Person?
}

class Person {
    var name : String = ""
    init(name : String) {
        self.name = name
    }
}

let book = Book()
let person = Person.init(name: "Roger")

book.author = person
book.author?.name

if let name = book.author?.name {
    print("Author name is \(name)")
} else {
    print("Annonymus author")
}

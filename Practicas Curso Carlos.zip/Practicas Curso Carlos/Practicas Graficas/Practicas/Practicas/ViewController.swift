//
//  ViewController.swift
//  Practicas
//
//  Created by Macbook on 19/09/18.
//  Copyright © 2018 netec. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var label = UILabel()
    var textField = UITextField()

    @IBOutlet weak var user: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        // UILabel
        /*label = UILabel(frame: CGRect(x: 85, y: 50, width: 200, height: 50))
        label.textAlignment = .center
        label.text = "¿What´s your name?"
        label.layer.borderWidth = 1
        self.view.addSubview(label)
        
        textField = UITextField(frame: CGRect(x: 85, y: 105, width: 200, height: 50))
        textField.textAlignment = NSTextAlignment.center
        textField.textColor = UIColor.red
        //textField.borderStyle = UITextBorderStyle.line
        textField.placeholder = "Your name here ..."
        self.view.addSubview(textField)
        
        let button = UIButton()
        button.frame = CGRect(x: 85, y: 160, width: 200, height: 50)
        button.backgroundColor = UIColor.lightGray
        button.setTitle("Send ", for: .normal)
        button.addTarget(self, action: #selector(buttonAction), for: .touchUpInside)
        self.view.addSubview(button)
        
        let imageName = "login.png"
        let image = UIImage(named: imageName)
        let imageView = UIImageView(image: image!)
        imageView.frame = CGRect(x: 160, y: 215, width: 50, height: 50)
        view.addSubview(imageView)*/
        
        
    }
    
    @objc func buttonAction(){
        label.text = "jajaja"
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}


//: Playground - noun: a place where people can play

var myArray = [Int]()
myArray.append(1)
print(myArray)
var myArray2 : Array<String> = []
myArray2.append("hola")
print(myArray2)
var mySet = Set<String>()
mySet.insert("holaaa")
print(mySet)
var myDictionary = [Int:String]()
myDictionary = [5: "holaa"]
myDictionary = [5: "holaa xd"]
print(myDictionary)

for (key , value) in myDictionary {
    print("La llave: \(key) cuenta con un valor de: \(value)")
}

//: Playground - noun: a place where people can play

//: Opcionales

var possibleNumber : String = "123"
var convertedNumber : Int? = Int(possibleNumber)
possibleNumber = "abc"
convertedNumber = Int(possibleNumber)

//: Optional Binding

var result : Int
var result2 : Int
var messageOB : String
var num = 6
possibleNumber = "4"
convertedNumber = Int(possibleNumber)

// Las siguientes dos lineas causan error porque el valor
// es un tipo opcional y no esta siendo forzado o desempaquetado.

//result = convertedNumber + num
//messageOB = "The result is: \(result)"

if let opt = convertedNumber{
    result = opt + num
}else{
    result = 0
}
messageOB = "The result is: \(result)"
print(messageOB)
// Descomente el siguiente bloque de codigo para validar el
// Optional Binding en un ciclo infinito.

/*
 while let opt =  convertedNumber{
 result2 = opt + num
 }
 messageOB = "The result is: \(result)"
 */

import Foundation

//: Operadores de Asignacion

let (x,y) = (1,2)
let z = 3

//: Operadores Aritmeticos

var a = z - 3       // Operación de Resta
a = y + x       // Operación de Suma
a = z * y       // Operación de Multiplicacion
a = 100 / z     // Operación de División
a = z % 2       // Operación de Módulo

//: Operador de asignacion compuesto
// La siguiente linea es una representacion de a = a + 2
a += 2

//: Operadores de identidad

class Auto: NSObject{}

let elAuto = Auto()
let miAuto = Auto()

print(type(of: elAuto))

if elAuto === miAuto {
    print("Pertenecen al mismo tipo")
}

let miOtroAuto = miAuto

if miOtroAuto === miAuto {
    print("Pertenecen al mismo tipo1")
}

//: Operador condicional ternario
// Es una abreviacion de un control de flujo llamado IF

a == 10 ? print("A es igual a 10") : print("A no es igual a 10")

//: Operador coalecente nulo
// Es una abreviacion de un condicional ternario pero
// este evalua un valor nulo al primer elemento.
// a != nil ? a! : z
(a ?? z)

//: Operadores de rango
(a..<10)

let allowedEntry = false

if (!allowedEntry) {
    print("ACCESS DENIED")
}

// Prints "ACCESS DENIED"

//: Playground - noun: a place where people can play

import Foundation

var fecha_inicio_evento_date_time : Date
var fecha_fin_evento_date_time : Date
let dateFormatter = DateFormatter()

let fecha_inicio_evento : String = "06/10/2018 08:20"
let fecha_fin_evento : String = "06/10/2018 13:00"

let otra_fecha_inicio_evento : String = "07/10/2018 08:20"

dateFormatter.dateFormat = "dd/MM/yyyy HH:mm" //Your date format
dateFormatter.timeZone = TimeZone(abbreviation: "GMT+0:00") //Current time zone
let begin_date = dateFormatter.date(from: fecha_inicio_evento) //according to date format your date string
let end_date = dateFormatter.date(from: fecha_fin_evento) //according to date format your date string

print(type(of: end_date))

let formatter = DateFormatter()
formatter.dateFormat = "dd.MM.yyyy"
let result = formatter.string(from: end_date!)
print(result)


    
let range = fecha_inicio_evento...fecha_fin_evento

if range.contains(otra_fecha_inicio_evento) {
    print("The date is inside the range")
} else {
    print("The date is outside the range")
}

//
//  LoginViewController.swift
//  Registro
//
//  Created by Macbook on 20/09/18.
//  Copyright © 2018 netec. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {
    
    var listaUsuario = Array<Usuario>()

    @IBOutlet weak var usuario: UITextField!
    @IBOutlet weak var contrasenia: UITextField!
    
    override func viewDidLoad() {
        let usuario_admin = Usuario.init(usuario: "admin", contrasenia: "admin")
        
        listaUsuario.append(usuario_admin)
        
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func entrar(_ sender: Any) {
        if usuario.text != "" && contrasenia.text != "" {
            var existeUsuario : Bool = false
            for usuarioTemp in listaUsuario {
                if usuarioTemp.contrasenia == contrasenia.text && usuarioTemp.usuario == usuario.text {
                    existeUsuario = true
                    break
                }
            }
            if existeUsuario {
                self.showAlert(title: "Exito", message: "Login correcto :)")
            }else {
                self.showAlert(title: "Error", message: "Usuario o contraseña invalidos...!")
            }
        }else {
            self.showAlert(title: "Error", message: "Usuario y contraseña requeridos...!")
        }
    }
    
    @IBAction func entrarConFacebook(_ sender: Any) {
        self.showAlert(title: "Error", message: "Lo sentimos mucho estamos presentando problemas de conexón, al intentar ingresar con Faceebok")
    }
    @IBAction func entrarConGoogle(_ sender: Any) {
        self.showAlert(title: "Error", message: "Lo sentimos mucho estamos presentando problemas de conexón, al intentar ingresar con Google")
    }
    
    private func showAlert(title : String, message : String) {
        let alerta: UIAlertController = UIAlertController.init(title: title, message: message, preferredStyle: UIAlertControllerStyle.alert);
        
        let okAlerta: UIAlertAction = UIAlertAction.init(title: "Aceptar", style: UIAlertActionStyle.default, handler: nil);
        
        let _ = UIAlertAction.init(title: "Cancelar", style: .destructive, handler: nil)
        
        alerta.addAction(okAlerta)
        
        present(alerta, animated: true, completion: nil);
    }
    
}

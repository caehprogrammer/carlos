//
//  ViewController.swift
//  Registro
//
//  Created by Macbook on 19/09/18.
//  Copyright © 2018 netec. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var nombre: UITextField!
    @IBOutlet weak var telefono: UITextField!
    @IBOutlet weak var correo: UITextField!
    @IBOutlet weak var contrasenia: UITextField!
    @IBOutlet weak var contrasenia_confirmacion: UITextField!
    @IBOutlet weak var sexo: UISegmentedControl!
    @IBOutlet weak var terminos_condiciones: UISwitch!
    @IBOutlet weak var dia: UITextField!
    @IBOutlet weak var mes: UITextField!
    @IBOutlet weak var anio: UITextField!
    var fecha_nacimiento : String!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func registrar(_ sender: Any) {
        let validacion = self.validarFormulario()
        if validacion {
            self.showAlert(title: "Correcto", message: "Registro exitoso :)")
        }
    }
    
    private func validarFormulario() -> Bool{
        var validado : Bool = true
        
        
        if(nombre.text == ""){
            validado = false
            self.showAlert(title: "Requerido", message: "El nombre es requerido.")
        } else if(correo.text == ""){
            validado = false
            self.showAlert(title: "Requerido", message: "El correo electrónico es requerido.")
        } else if contrasenia.text == "" {
            validado = false
            self.showAlert(title: "Requerido", message: "La contraseña es requerida")
        }else if contrasenia.text != contrasenia_confirmacion.text {
            validado = false
            self.showAlert(title: "Requerido", message: "Las contraseñas no coinsiden favor de validar.")
        }
        if dia.text != "" && mes.text != "" && anio.text != "" {
            fecha_nacimiento = dia.text!+"/"+mes.text!+"/"+anio.text!
        }else {
            validado = false
            self.showAlert(title: "Requerido", message: "La fecha de nacimiento es requerida")
        }
        if !terminos_condiciones.isOn {
            validado = false
            self.showAlert(title: "Requerido", message: "Es necesario aseptar los terminos y condiciones")
        }
        return validado
    }
    
    private func showAlert(title : String, message : String) {
        let alerta: UIAlertController = UIAlertController.init(title: title, message: message, preferredStyle: UIAlertControllerStyle.alert);
        
        let okAlerta: UIAlertAction = UIAlertAction.init(title: "Aceptar", style: UIAlertActionStyle.default, handler: nil);
        
        let _ = UIAlertAction.init(title: "Cancelar", style: .destructive, handler: nil)
        
        alerta.addAction(okAlerta)
        
        present(alerta, animated: true, completion: nil);
    }
    
    
}



//
//  Usuarios.swift
//  Práctica 2 - Login y Registro
//
//  Created by Macbook on 21/09/18.
//  Copyright © 2018 netec. All rights reserved.
//
class Usuario {
    var usuario : String
    var contrasenia : String
    
    init(usuario : String, contrasenia : String) {
        self.usuario = usuario
        self.contrasenia = contrasenia
    }
}

//: Playground - noun: a place where people can play

import Foundation

// Ejemplo del uso de VAR
var distance: Double
distance = 10
print(distance)

print("Distancia \(distance)")

distance = 15

print(distance)

let velocity: Double
velocity = 10
print(velocity)

// Declaración de tipo en forma explicita.
let myExplicitValue : String = "My Weight is"
let myExplicitValue2 : Double = 70

// Declaración de tipo en forma Implícita.
let myImplicitValue = "My Weight is"

// Para incluir una variable (no String) dentro de un String utiliza \().
let yourWeight = "Your weight is \(myExplicitValue2)"

// Los Strings no permiten la conversión implícita de tipo de dato.
let myWeight = myImplicitValue + String(myExplicitValue2)

var doble_temp = Double("9.9")


var str = "Hello, playground"

str.insert("¡", at: str.startIndex)
print(str)
str.insert("!", at: str.endIndex)
print(str)
str.insert("s", at: str.index(before: str.endIndex))
print(str)
str.insert(contentsOf: " guys", at: str.index(before: str.endIndex))

// Concatenación de Strings
print("..." + str)
print("Esto es: \(str)")

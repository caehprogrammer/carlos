//: Playground - noun: a place where people can play
func addTwoNum(a:Int,b:Int) -> Int{
    return a+b
}

func mutiplyTwoNum(a:Int, b:Int) -> Int{
    return a*b
}

func printMathResult(operation: (Int,Int) -> Int,a: Int,b: Int) -> Void{
    print("Result: \(operation(a,b))")
}

printMathResult(operation: mutiplyTwoNum, a: 2, b: 3)

//: Tuplas

let portFTP = ("File Transfer Protocol",21,true)
let portFTP2 = ("File Transfer Protocol",21)
let portSSH = ("Secure Shell",22,false)
var portSMTP = (desc: "Send Mail Transfer Protocol", num: 25, active: false)

var message : String
var (description,number,_) = portFTP
var (description2, number2) = portFTP2
message = "The port number \(number) corresponds to \(description)"
description = portSSH.0
number = portSSH.1
// status = portSSH.2 // error
message = "The port number \(number) corresponds to \(description)"
portSMTP.active = true
portSMTP.2

var tupla2 = (booleano : true, bool2 : false, string : "holaaa")
print(tupla2.bool2)

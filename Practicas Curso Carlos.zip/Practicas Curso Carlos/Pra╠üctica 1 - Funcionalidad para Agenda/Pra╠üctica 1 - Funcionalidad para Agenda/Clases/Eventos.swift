import Foundation

class Eventos {
    var nombre : String?
    var detalle : String?
    var contactos = Array<Contacto>()
    var fecha_inicio_evento_date_time : Date
    var fecha_fin_evento_date_time : Date
    let dateFormatter = DateFormatter()
    
    init(nombre : String, detalle : String, fecha_inicio_evento : String, fecha_fin_evento : String) {
        self.nombre = nombre
        self.detalle = detalle
        dateFormatter.dateFormat = "dd-MM-yyyy HH:mm"
        dateFormatter.timeZone = TimeZone(abbreviation: "GMT+0:00")
        self.fecha_inicio_evento_date_time = dateFormatter.date(from: fecha_inicio_evento)!
        self.fecha_fin_evento_date_time = dateFormatter.date(from: fecha_fin_evento)!
    }
    
    func agregarContacto(contacto : Contacto) -> Void {
        self.contactos.append(contacto)
        print("Contacto "+contacto.nombre_completo+" agregado al evento "+self.nombre!)
    }
    
    func mostrarInfo() -> Void {
        print("Nombre: "+nombre!)
        print("Detalle: "+detalle!)
        print("Fecha inicio de evento: \(fecha_inicio_evento_date_time)")
        print("Fecha fin evento: \(fecha_fin_evento_date_time)")
        print("Contactos en el evento: \(contactos.count)")
        print("-----")
        for contacto in contactos{
            print(contacto.mostrarInfo())
        }
        print("-----")
    }
}

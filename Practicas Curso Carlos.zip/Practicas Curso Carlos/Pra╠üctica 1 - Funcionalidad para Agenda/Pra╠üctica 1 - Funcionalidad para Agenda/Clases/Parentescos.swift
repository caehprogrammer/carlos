//
//  Parentescos.swift
//  Práctica 1
//
//  Created by Macbook on 19/09/18.
//  Copyright © 2018 netec. All rights reserved.
//
enum Parentescos : String{
    case ABUELO
    case ABUELA
    case MADRE
    case PADRE
    case HERMANO
    case HERMANA
    case TIO
    case TIA
    case PRIMO
    case AMIGO
    case AMIGA
}

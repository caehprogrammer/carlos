//
//  Persona.swift
//  Práctica 1
//
//  Created by Macbook on 18/09/18.
//  Copyright © 2018 netec. All rights reserved.
//
import Foundation

class Persona {
    
    var nombre_completo : String
    var edad : Int
    var fecha_nacimiento : String
    var domicilio : String
    var correo_electronico : String
    var contactos = Array<Contacto>()
    var eventos = Array<Eventos>()
    let dateFormatter = DateFormatter()
    
    init(nombre_completo: String, fecha_nacimiento: String, domicilio: String, correo_electronico : String) {
        dateFormatter.dateFormat = "dd-MM-yyyy" //Your date format
        dateFormatter.timeZone = TimeZone(abbreviation: "GMT+0:00") //Current time zone
        let date1 = dateFormatter.date(from: fecha_nacimiento) //according to date format your date string
        
        let now = Date()
        let birthday: Date = date1!
        let calendar = Calendar.current
        
        let ageComponents = calendar.dateComponents([.year], from: birthday, to: now)
        let age = ageComponents.year!
        
        self.nombre_completo  = nombre_completo
        self.edad = age
        self.fecha_nacimiento = fecha_nacimiento
        self.domicilio = domicilio
        self.correo_electronico = correo_electronico
    }
    
    func nuevoContacto(contacto:Contacto) -> Void{
        contactos.append(contacto)
        print(contacto.nombre_completo+" agregado a la lista de contactos...")
    }
    
    func programarEvento(nuevo_evento :  Eventos) -> Void {
        if eventos.count==0{
            self.agregarEvento(nuevo_evento: nuevo_evento)
        }else{
            var add : Bool = true
            for evento in eventos {
                let range = evento.fecha_inicio_evento_date_time...evento.fecha_fin_evento_date_time
                if range.contains(nuevo_evento.fecha_inicio_evento_date_time) {
                    add = false
                    break
                }
            }
            
            if add {
                self.agregarEvento(nuevo_evento: nuevo_evento)
            }else{
                print("Evento "+nuevo_evento.nombre!+" no agregado, fecha y hora ocupados")
            }
        }
    }
    
    private func agregarEvento(nuevo_evento :  Eventos){
        eventos.append(nuevo_evento)
        
        print("Numero \(eventos.count) Nuevo evento "+nuevo_evento.nombre!+" agregado a la agenda...")
        
    }
    
    func mostrarEventos()->Void{
        print("Eventos: \(eventos.count)")
        print("-----")
        for evento in eventos {
            print(evento.mostrarInfo())
        }
        print("-----")
    }
    
    func mostrarContactos()->Void{
        print("Contactos: \(contactos.count)")
        print("-----")
        for contacto in contactos {
            print(contacto.mostrarInfo())
        }
        print("-----")
    }
    
    func mostrarParentesco(top_parentesco : Int)->Void{
        print("-----")
        for (index, contacto) in contactos.enumerated() {
            if index < top_parentesco {
                print("Nombre contacto \(index+1): "+contacto.nombre_completo + " Parentesco: \(contacto.parentesco.rawValue)")
            }else{
                break
            }
        }
        print("-----")
    }
    
    public func mostrarInfo() -> Void {
        print("Nombre Completo: "+nombre_completo)
        print("Fecha Nacimiento: "+fecha_nacimiento)
        print("Edad: \(edad)")
        print("Domicilio: "+domicilio)
        print("Correo Electronico: "+correo_electronico)
    }
    
}

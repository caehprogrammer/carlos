//
//  Contacto.swift
//  Práctica 1
//
//  Created by Macbook on 18/09/18.
//  Copyright © 2018 netec. All rights reserved.
//
import Foundation

class Contacto: Persona{
    var empresa : String
    var parentesco : Parentescos
    
    init(nombre_completo: String, fecha_nacimiento: String, domicilio: String, correo_electronico:String, parentesco:Parentescos, empresa : String) {
        self.empresa = empresa
        self.parentesco = parentesco
        super.init(nombre_completo: nombre_completo, fecha_nacimiento: fecha_nacimiento, domicilio: domicilio, correo_electronico: correo_electronico)
    }
    
    override func mostrarInfo() -> Void {
        print("Nombre Completo: "+nombre_completo)
        print("Empresa: "+empresa)
        print("Parentesco: "+parentesco.rawValue)
        print("Correo Electronico: "+correo_electronico)
        print("Edad: \(edad)")
        print("Domicilio: "+domicilio)
    }
    
    func mostrarParentesco() -> Void {
         print(parentesco.rawValue)
    }
}

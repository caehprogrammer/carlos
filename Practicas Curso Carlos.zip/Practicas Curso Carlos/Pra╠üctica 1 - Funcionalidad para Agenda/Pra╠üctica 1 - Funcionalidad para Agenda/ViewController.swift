//
//  ViewController.swift
//  Práctica 1
//
//  Created by Macbook on 18/09/18.
//  Copyright © 2018 netec. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        //super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        let yo : Persona = Persona(nombre_completo: "Carlos Antonio Escobar Hernandez", fecha_nacimiento: "05-11-1994", domicilio: "Conocido", correo_electronico: "carlo@mail.com")
        
        let contacto_jon = Contacto(nombre_completo: "Jonathan", fecha_nacimiento: "23-03-1992", domicilio: "Ciudad de Mèxico", correo_electronico: "jon@mail.com", parentesco: Parentescos.AMIGO, empresa: "GS")
        
        let contacto_karen = Contacto(nombre_completo: "Karen Sarahi Armendariz", fecha_nacimiento: "23-10-1992", domicilio: "Puebla", correo_electronico: "karen@mail.com", parentesco: Parentescos.AMIGA, empresa: "GS")
        
        let contacto_omar = Contacto(nombre_completo: "Omar Alejandro Acuña Lara", fecha_nacimiento: "29-10-1989", domicilio: "Zacatecas", correo_electronico: "omar@mail.com", parentesco: Parentescos.AMIGO, empresa: "GS")
        
        let contacto_antonio = Contacto(nombre_completo: "Antonio Jimenez Miranda", fecha_nacimiento: "12-08-1993", domicilio: "Morelos", correo_electronico: "antonio@mail.com", parentesco: Parentescos.AMIGO, empresa: "GS")
        
        let contacto_aime = Contacto(nombre_completo: "Aime Mondragon Olmos", fecha_nacimiento: "15-05-1993", domicilio: "Mexico", correo_electronico: "aime@mail.com", parentesco: Parentescos.AMIGA, empresa: "Vendedora de Carros")
        
        let contacto_eduardo = Contacto(nombre_completo: "Eduardo Escobar Hernandez", fecha_nacimiento: "15-11-1995", domicilio: "Mexico", correo_electronico: "eduardo@mail.com", parentesco: Parentescos.HERMANO, empresa: "Control de trafico telefonico")
        
        let contacto_hilda = Contacto(nombre_completo: "Hilda Gonzalez Olivares", fecha_nacimiento: "04-03-1993", domicilio: "Puebla", correo_electronico: "hilda@mail.com", parentesco: Parentescos.AMIGA, empresa: "GS")
        
        let contacto_ivan = Contacto(nombre_completo: "Ivan", fecha_nacimiento: "04-07-1993", domicilio: "Veracruz", correo_electronico: "ivan@mail.com", parentesco: Parentescos.AMIGO, empresa: "GS")
        
        yo.nuevoContacto(contacto: contacto_jon)
        yo.nuevoContacto(contacto: contacto_karen)
        yo.nuevoContacto(contacto: contacto_omar)
        yo.nuevoContacto(contacto: contacto_antonio)
        yo.nuevoContacto(contacto: contacto_aime)
        yo.nuevoContacto(contacto: contacto_eduardo)
        yo.nuevoContacto(contacto: contacto_hilda)
        yo.nuevoContacto(contacto: contacto_ivan)
        
        let evento_paracaidas : Eventos = Eventos.init(nombre: "Saltar del paracaidas", detalle: "Saltaremos del paracaidas en Tequesqitengo", fecha_inicio_evento: "06-10-2018 08:00", fecha_fin_evento : "06-10-2018 13:30")
        
        
        let evento_sixflags : Eventos = Eventos.init(nombre: "Dia en Sixflags", detalle: "Iremos a los juegos mecanicos de sixflags", fecha_inicio_evento: "06-12-2018 08:00", fecha_fin_evento : "06-12-2018 18:00")
        
        
        let evento_gotcha : Eventos = Eventos.init(nombre: "Dia de accion en el gotcha", detalle: "Armar equipos y jugar unos contra otros", fecha_inicio_evento: "08-12-2018 08:00", fecha_fin_evento : "08-12-2018 15:00")
        
        let evento_salida_imprevista : Eventos = Eventos.init(nombre: "Salida imprevista", detalle: "Salir algun lugar", fecha_inicio_evento: "08-12-2018 08:00", fecha_fin_evento : "08-12-2018 15:00")
        
        evento_paracaidas.agregarContacto(contacto: contacto_karen)
        evento_paracaidas.agregarContacto(contacto: contacto_omar)
        evento_paracaidas.agregarContacto(contacto: contacto_aime)
        evento_paracaidas.agregarContacto(contacto: contacto_hilda)
        evento_paracaidas.agregarContacto(contacto: contacto_ivan)
        
        evento_sixflags.agregarContacto(contacto: contacto_omar)
        evento_sixflags.agregarContacto(contacto: contacto_jon)
        evento_sixflags.agregarContacto(contacto: contacto_ivan)
        evento_sixflags.agregarContacto(contacto: contacto_karen)
        evento_sixflags.agregarContacto(contacto: contacto_hilda)
        
        evento_gotcha.agregarContacto(contacto: contacto_omar)
        evento_gotcha.agregarContacto(contacto: contacto_jon)
        evento_gotcha.agregarContacto(contacto: contacto_ivan)
        evento_gotcha.agregarContacto(contacto: contacto_karen)
        
        evento_salida_imprevista.agregarContacto(contacto: contacto_eduardo)
        
        yo.programarEvento(nuevo_evento : evento_paracaidas)
        yo.programarEvento(nuevo_evento : evento_sixflags)
        yo.programarEvento(nuevo_evento : evento_gotcha)
        yo.programarEvento(nuevo_evento: evento_salida_imprevista)
        
        yo.mostrarInfo()
        
        yo.mostrarParentesco(top_parentesco: 5)
        
        yo.mostrarContactos()
        yo.mostrarEventos()
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}


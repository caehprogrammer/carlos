//: Playground - noun: a place where people can play

import Foundation

let dateFormatter = DateFormatter()

    
    dateFormatter.dateFormat = "dd-mm-yyyy" //Your date format
    dateFormatter.timeZone = TimeZone(abbreviation: "GMT+0:00") //Current time zone
    let date1 = dateFormatter.date(from: "05-11-1994") //according to date format your date string
    
    let now = Date()
    let birthday: Date = date1!
    let calendar = Calendar.current
    
    let ageComponents = calendar.dateComponents([.year], from: birthday, to: now)
    let age = ageComponents.year!
    let edad : Int = age

    print(edad)

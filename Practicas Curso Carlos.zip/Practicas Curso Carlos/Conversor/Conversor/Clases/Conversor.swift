//
//  Unidad.swift
//  Conversor
//
//  Created by Macbook on 21/09/18.
//  Copyright © 2018 netec. All rights reserved.
//
class Conversor {
    var nombre : String
    var valor : Double
    init(nombre : String, valor : Double) {
        self.nombre = nombre
        self.valor = valor
    }
}

//
//  Unidades.swift
//  Conversor
//
//  Created by Macbook on 21/09/18.
//  Copyright © 2018 netec. All rights reserved.
//
enum Unidades : String {
    
    case Kilometros = "Kilómetros"
    case Millas = "Millas"
    case Metro = "Metro"
    case Centimetro = "Centimetro"
    case Milimetro = "Milimetro"
    case Yarda = "Yarda"
    case Pie = "Pie"
    case Pulgada = "Pulgada"
    
    
}

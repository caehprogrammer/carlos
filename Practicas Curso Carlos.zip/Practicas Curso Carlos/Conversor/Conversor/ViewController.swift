//
//  ViewController.swift
//  Conversor
//
//  Created by Macbook on 21/09/18.
//  Copyright © 2018 netec. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var Valor: UITextField!
    @IBOutlet weak var Unidad1: UIPickerView!
    @IBOutlet weak var Unidad2: UIPickerView!
    @IBOutlet weak var Resultado: UILabel!
    @IBOutlet weak var Limpiar: UIButton!
    
    var list_unidades = Array<String>()
    
    override func viewDidLoad() {
        list_unidades.append(Unidades.Centimetro.rawValue)
        list_unidades.append(Unidades.Kilometros.rawValue)
        list_unidades.append(Unidades.Metro.rawValue)
        list_unidades.append(Unidades.Milimetro.rawValue)
        list_unidades.append(Unidades.Millas.rawValue)
        list_unidades.append(Unidades.Pie.rawValue)
        list_unidades.append(Unidades.Pulgada.rawValue)
        Unidad1.dataSource = self
        Unidad1.delegate = self
        
        Unidad2.dataSource = self
        Unidad2.delegate = self
        
        
        
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    @IBAction func limpiar(_ sender: Any) {
        Resultado.text = ""
        Valor.text = ""
    }
    
    @IBAction func calcularValor(_ sender: Any) {
        self.calculate()
    }
    
    private func calculate(){
        if Valor.text != ""{
            var resul : String = ""
            let selectedValueUnidad1 : String = list_unidades[Unidad1.selectedRow(inComponent: 0)]
            let selectedValueUnidad2 : String = list_unidades[Unidad2.selectedRow(inComponent: 0)]
            
            if selectedValueUnidad1 == Unidades.Metro.rawValue &&  selectedValueUnidad2 == Unidades.Centimetro.rawValue{
                let valueParsed = Double(Valor.text!)
                let value = Double(100)
                resul = "\(valueParsed!*value)"
            } else if selectedValueUnidad2 == Unidades.Metro.rawValue &&  selectedValueUnidad1 == Unidades.Centimetro.rawValue{
                let valueParsed = Double(Valor.text!)
                let value = Double(100)
                resul = "\(valueParsed!/value)"
            }
            
            if selectedValueUnidad1 == Unidades.Centimetro.rawValue &&  selectedValueUnidad2 == Unidades.Kilometros.rawValue{
                let valueParsed = Double(Valor.text!)
                let value = Double(100)
                resul = "\(valueParsed!*value)"
            } else if selectedValueUnidad2 == Unidades.Metro.rawValue &&  selectedValueUnidad1 == Unidades.Centimetro.rawValue{
                let valueParsed = Double(Valor.text!)
                let value = Double(100)
                resul = "\(valueParsed!/value)"
            }
            Resultado.text = resul
        }
    }
}

extension ViewController : UIPickerViewDataSource{
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return self.list_unidades.count
    }
    
}

extension ViewController : UIPickerViewDelegate{
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return self.list_unidades[row] as String
    }
    
}


//
//  ViewController.swift
//  Práctica 3 - Elementos gráficos Agenda
//
//  Created by Macbook on 21/09/18.
//  Copyright © 2018 netec. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource{

    let yo : Persona = Persona(nombre_completo: "Carlos Antonio Escobar Hernandez", fecha_nacimiento: "05-11-1994", domicilio: "Conocido", correo_electronico: "carlo@mail.com")
    
    var listaContactos = [String]()
    var contactos = Array<Contacto>()
    
    @IBOutlet weak var tabla_contactos: UITableView!
    
    @IBOutlet weak var nombre_label: UILabel!
    
    private func loadData() {
        let contacto_jon = Contacto(nombre_completo: "Jonathan", fecha_nacimiento: "23-03-1992", domicilio: "Ciudad de Mèxico", correo_electronico: "jon@mail.com", parentesco: Parentescos.AMIGO, empresa: "GS")
        
        let contacto_karen = Contacto(nombre_completo: "Karen Sarahi Armendariz", fecha_nacimiento: "23-10-1992", domicilio: "Puebla", correo_electronico: "karen@mail.com", parentesco: Parentescos.AMIGA, empresa: "GS")
        
        let contacto_omar = Contacto(nombre_completo: "Omar Alejandro Acuña Lara", fecha_nacimiento: "29-10-1989", domicilio: "Zacatecas", correo_electronico: "omar@mail.com", parentesco: Parentescos.AMIGO, empresa: "GS")
        
        let contacto_antonio = Contacto(nombre_completo: "Antonio Jimenez Miranda", fecha_nacimiento: "12-08-1993", domicilio: "Morelos", correo_electronico: "antonio@mail.com", parentesco: Parentescos.AMIGO, empresa: "GS")
        
        let contacto_aime = Contacto(nombre_completo: "Aime Mondragon Olmos", fecha_nacimiento: "15-05-1993", domicilio: "Mexico", correo_electronico: "aime@mail.com", parentesco: Parentescos.AMIGA, empresa: "Vendedora de Carros")
        
        let contacto_eduardo = Contacto(nombre_completo: "Eduardo Escobar Hernandez", fecha_nacimiento: "15-11-1995", domicilio: "Mexico", correo_electronico: "eduardo@mail.com", parentesco: Parentescos.HERMANO, empresa: "Control de trafico telefonico")
        
        let contacto_hilda = Contacto(nombre_completo: "Hilda Gonzalez Olivares", fecha_nacimiento: "04-03-1993", domicilio: "Puebla", correo_electronico: "hilda@mail.com", parentesco: Parentescos.AMIGA, empresa: "GS")
        
        let contacto_ivan = Contacto(nombre_completo: "Ivan", fecha_nacimiento: "04-07-1993", domicilio: "Veracruz", correo_electronico: "ivan@mail.com", parentesco: Parentescos.AMIGO, empresa: "GS")
        
        yo.nuevoContacto(contacto: contacto_jon)
        yo.nuevoContacto(contacto: contacto_karen)
        yo.nuevoContacto(contacto: contacto_omar)
        yo.nuevoContacto(contacto: contacto_antonio)
        yo.nuevoContacto(contacto: contacto_aime)
        yo.nuevoContacto(contacto: contacto_eduardo)
        yo.nuevoContacto(contacto: contacto_hilda)
        yo.nuevoContacto(contacto: contacto_ivan)
        
        for contacto_temp in yo.contactos{
            listaContactos.append(contacto_temp.nombre_completo)
        }
        contactos = yo.contactos
        
        nombre_label.text = yo.nombre_completo
    }
    
    override func viewDidLoad() {
        
        self.loadData()
        
        tabla_contactos.separatorStyle = .none
        tabla_contactos.delegate = self
        tabla_contactos.dataSource = self
        tabla_contactos.allowsSelection = true
        
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    

    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return listaContactos.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        let row = indexPath.row
        cell.textLabel?.text = listaContactos[row]
        return cell
    }
    
     func tableView(_ tableView: UITableView,
                    didSelectRowAt indexPath: IndexPath) {
        //getting the index path of selected row
        let indexPath = tableView.indexPathForSelectedRow
        
        //getting the current cell from the index path
        let currentCell = tableView.cellForRow(at: indexPath!)! as UITableViewCell
        
        //getting the text of that cell
        let currentItem = currentCell.textLabel!.text
        
        var contacto_seleccionado : Contacto = Contacto(nombre_completo: "", fecha_nacimiento: "15-11-1995", domicilio: "", correo_electronico: "", parentesco: Parentescos.HERMANO, empresa: "")
        
        for contacto_temp in contactos {
            if(contacto_temp.nombre_completo == currentItem!){
                contacto_seleccionado = contacto_temp
                break
            }
        }
        let info_contacto: String = "Nombre: \(contacto_seleccionado.nombre_completo) Edad: \(contacto_seleccionado.edad) Domicilio: \(contacto_seleccionado.domicilio) Empresa: \(contacto_seleccionado.empresa) Parentesco: \(contacto_seleccionado.parentesco) Correo electrónico: \(contacto_seleccionado.correo_electronico)"
        self.showAlert(title: "Información", message: info_contacto)
        
    }
    
    private func showAlert(title : String, message : String) {
        let alerta: UIAlertController = UIAlertController.init(title: title, message: message, preferredStyle: UIAlertControllerStyle.alert);
        
        let okAlerta: UIAlertAction = UIAlertAction.init(title: "Aceptar", style: UIAlertActionStyle.default, handler: nil);
        
        let _ = UIAlertAction.init(title: "Cancelar", style: .destructive, handler: nil)
        
        alerta.addAction(okAlerta)
        
        present(alerta, animated: true, completion: nil);
    }
}
